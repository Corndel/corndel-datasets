import json
import base64
import boto3
from decimal import Decimal  # Import Decimal for DynamoDB number support

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
table_name = 'WeatherData'
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    """Process Kinesis data and store it in DynamoDB."""
    for record in event['Records']:
        # Decode the Kinesis data (Base64 to JSON)
        payload = json.loads(base64.b64decode(record['kinesis']['data']).decode('utf-8'), parse_float=Decimal)
        print(f"Processing record: {payload}")
        
        # Write the data to DynamoDB
        try:
            table.put_item(
                Item={
                    'City': payload['city'],          # Partition key
                    'Timestamp': payload['timestamp'], # Sort key
                    'Temperature': payload['temperature']  # Additional attribute (Decimal)
                }
            )
            print(f"Record stored: {payload}")
        except Exception as e:
            print(f"Failed to store record: {e}")
    
    return {"statusCode": 200, "body": "Data processed"}
