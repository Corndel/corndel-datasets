import json
import boto3
import urllib.request
from datetime import datetime  # Import datetime for current UTC timestamp

# Initialize Kinesis client
kinesis_client = boto3.client('kinesis', region_name='us-east-1')
stream_name = 'CorndelDataStream121'

# Base URL for Open-Meteo API
base_url = "https://api.open-meteo.com/v1/forecast"
locations = [
    {"city": "London", "latitude": 51.5072, "longitude": -0.1276},
    {"city": "Manchester", "latitude": 53.4808, "longitude": -2.2426},
    {"city": "Edinburgh", "latitude": 55.9533, "longitude": -3.1883}
]

def fetch_weather_data(location):
    """Fetch weather data from Open-Meteo API."""
    params = f"?latitude={location['latitude']}&longitude={location['longitude']}&hourly=temperature_2m&timezone=Europe/London"
    url = base_url + params
    response = urllib.request.urlopen(url)
    data = json.load(response)
    temperature = data["hourly"]["temperature_2m"][0]

    # Use the current UTC time for the timestamp
    current_timestamp = datetime.utcnow().isoformat()

    return {"city": location["city"], "temperature": temperature, "timestamp": current_timestamp}

def lambda_handler(event, context):
    """Send weather data to Kinesis."""
    for location in locations:
        weather_data = fetch_weather_data(location)
        print(f"Sending to Kinesis: {json.dumps(weather_data)}")
        kinesis_client.put_record(
            StreamName=stream_name,
            Data=json.dumps(weather_data),
            PartitionKey=weather_data["city"]
        )
    return {"statusCode": 200, "body": "Weather data sent to Kinesis"}
